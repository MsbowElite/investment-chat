using Microsoft.AspNetCore.Mvc.RazorPages;

namespace identity_no_seed.Pages.Account;

public class AccessDeniedModel : PageModel
{
    public void OnGet()
    {
    }
}