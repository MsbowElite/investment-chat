﻿namespace InvestmentChat.Web.Configurations
{
    public class AppSettings
    {
        public string IdentityAPIUrl { get; set; }
        public string SignalRHubUrl { get; set; }
    }
}
